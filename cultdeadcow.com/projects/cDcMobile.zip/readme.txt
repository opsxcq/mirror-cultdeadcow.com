Hella Kitty of CULT OF THE DEAD COW provides you with the
cDc Mobile Content Package!  Put it in it's place:  near to you, in your
phone, in the front pocket of your jeans, nuzzling against /your/ package!

Didn't think you were trendy enough so you had to go and buy an iPhone?  Oh,
too broke?  So you bought an iPod Touch?  You're in luck!  Show your cDc pride
by displaying the most cutting-edge wallpapers for either!  Someone from the
cDc calling you?  Set them up with with a ringtone so you know when the elite
of the elite are manifesting in your pocket.

If you were looking for cDc Ringtones for a phone that isn't an iPhone, you're
still in luck.  The ringtones are provided in MP3, M4R, and AMR-nb formats,
which should cover every custom ringtone-enabled phone.

.ooM
