/* * * * * * * *
 * Tao Te Ching
 * taoteching.h
 * (C) 2008 Jake Kara
 * Distributed by cDc communications
 * Inspired by JSchrier's work http://homepage.mac.com/jschrier/gameboy/
 * * * * * * * * */

char * tao [] = { 
//1
	"The Way that can be experienced is not true",  
	"The world that can be constructed is not real",
	"The Way manifests all that happens and may happen",
	"The world represents all that exists and may exist",

	"To experience without abstraction is to sense the world",
	"To experience with abstraction is to know the world",
	
	"Beyond the gate of experience flows the Way",
	
//2
	"When beauty is abstracted, then ugliness has been implied",
	"When good is abstracted then evil has been implied",
	"When good is abstracted then evil has been implied."

};
