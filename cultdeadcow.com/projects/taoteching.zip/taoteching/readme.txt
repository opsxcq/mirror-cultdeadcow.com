* Tao Te Ching for Gameboy
* (C) 2008 Jake Kara
* Distributed by cDc communications
* Inspired by JSchrier's work http://homepage.mac.com/jschrier/gameboy/

A while ago I was inspired by J Schrier's Gameboy software and hardware 
research (http://homepage.mac.com/jschrier/gameboy/) which explores the
_I Ching_, the Stations of the Cross, the Rosary, and Mao Tse Tung's 
_Little Red Book_. So I modified an Apple IIe program that I always 
considered to be Taoist in nature and rewrote it for the gameboy.

It generates nonstatic images that at times can be quite visually appealing.
You can pause it at any time, but it will spit out a verse from the classical
Chinese text, the _Tao Te Ching_. The point is that you can never pause or 
even consciously consider any moment without losing its beauty through 
intellectual abstraction.

I never finished the project -- I was going to add color and package this in
cartridge form, and enter the entire classical text, but since I have to pack
up most of my computers in my move this weekend, I didn't want it to be 
forgotten. If anyone wants to pick up where I left off, the code is included. 

Note that the menu screen and some of the screen captures display "HAL666" 
because that was the name of the Apple IIe program I originally wrote to be 
used on stage.

CONTENTS
* readme.txt - this file, duh
* instructions.txt - how to use it
* taoteching.c - the image generation
* taoteching.h - the Tao
* taoteching.gb - compiled Gameboy ROM
* WelcomeScreen.jpg - welcome screen screenshot
* notthetrueway.jpg - screenshot
* HAL666BW1.jpg - screenshot

.ooM