#include "config.h"
#include <ctype.h>
#include <stdio.h>
#include <strings.h>
#include "helpstrings.h"


void givehelpcommand(char *arg1)
{
  if (strcasecmp(arg1, "HOST") == 0)			puts(hosthelp);
  else if (strcasecmp(arg1, "QUIT") == 0)		puts(quithelp);
  else if (strcasecmp(arg1, "PING") == 0)		puts(pinghelp);
  else if (strcasecmp(arg1, "PINGLIST") == 0)		puts(pinglisthelp);
  else if (strcasecmp(arg1, "SWEEP") == 0)		puts(sweephelp);
  else if (strcasecmp(arg1, "SWEEPLIST") == 0)		puts(sweeplisthelp);
  else if (strcasecmp(arg1, "SHELL") == 0)		puts(shellhelp);
  else if (strcasecmp(arg1, "STATUS") == 0)		puts(statushelp);
  else if (strcasecmp(arg1, "PASSWD") == 0)		puts(passwdhelp);
  else if (strcasecmp(arg1, "DIR") == 0)		puts(dirhelp);
  else if (strcasecmp(arg1, "CD") == 0)			puts(cdhelp);
  else if (strcasecmp(arg1, "DEL") == 0)		puts(delhelp);
  else if (strcasecmp(arg1, "GET") == 0)		puts(gethelp);
  else if (strcasecmp(arg1, "PUT") == 0)		puts(puthelp);
  else if (strcasecmp(arg1, "COPY") == 0)		puts(copyhelp);
  else if (strcasecmp(arg1, "FIND") == 0)		puts(findhelp);
  else if (strcasecmp(arg1, "FREEZE") == 0)		puts(freezehelp);
  else if (strcasecmp(arg1, "MELT") == 0)		puts(melthelp);
  else if (strcasecmp(arg1, "VIEW") == 0)		puts(viewhelp);
  else if (strcasecmp(arg1, "REN") == 0)		puts(renhelp);
  else if (strcasecmp(arg1, "MD") == 0)			puts(mdhelp);
  else if (strcasecmp(arg1, "RD") == 0)			puts(rdhelp);
  else if (strcasecmp(arg1, "INFO") == 0)		puts(infohelp);
  else if (strcasecmp(arg1, "PASSES") == 0)		puts(passeshelp);
  else if (strcasecmp(arg1, "DIALOG") == 0)		puts(dialoghelp);
  else if (strcasecmp(arg1, "KEYLOG") == 0)		puts(keyloghelp);
  else if (strcasecmp(arg1, "REBOOT") == 0)		puts(reboothelp);
  else if (strcasecmp(arg1, "NETVIEW") == 0)		puts(netviewhelp);
  else if (strcasecmp(arg1, "NETCONNECT") == 0)		puts(netconnecthelp);
  else if (strcasecmp(arg1, "NETDISCONNECT") == 0)	puts(netdisconnecthelp);
  else if (strcasecmp(arg1, "NETLIST") == 0)		puts(netlisthelp);
  else if (strcasecmp(arg1, "RESOLVE") == 0)		puts(resolvehelp);
  else if (strcasecmp(arg1, "SHARELIST") == 0)		puts(sharelisthelp);
  else if (strcasecmp(arg1, "SHAREADD") == 0)		puts(shareaddhelp);
  else if (strcasecmp(arg1, "SHAREDEL") == 0)		puts(sharedelhelp);
  else if (strcasecmp(arg1, "PROCLIST") == 0)		puts(proclisthelp);
  else if (strcasecmp(arg1, "PROCKILL") == 0)		puts(prockillhelp);
  else if (strcasecmp(arg1, "PROCSPAWN") == 0)		puts(procspawnhelp);
  else if (strcasecmp(arg1, "LISTCAPS") == 0)		puts(listcapshelp);
  else if (strcasecmp(arg1, "CAPSCREEN") == 0)		puts(capscreenhelp);
  else if (strcasecmp(arg1, "CAPFRAME") == 0)		puts(capframehelp);
  else if (strcasecmp(arg1, "CAPAVI") == 0)		puts(capavihelp);
  else if (strcasecmp(arg1, "SOUND") == 0)	        puts(soundhelp);
  else if (strcasecmp(arg1, "REDIRLIST") == 0)		puts(redirlisthelp);
  else if (strcasecmp(arg1, "REDIRDEL") == 0)		puts(redirdelhelp);
  else if (strcasecmp(arg1, "REDIRADD") == 0)		puts(rediraddhelp);
  else if (strcasecmp(arg1, "APPADD") == 0)		puts(appaddhelp);
  else if (strcasecmp(arg1, "APPDEL") == 0)		puts(appdelhelp);
  else if (strcasecmp(arg1, "APPLIST") == 0)		puts(applisthelp);
  else if (strcasecmp(arg1, "REGMAKEKEY") == 0)		puts(regmakekeyhelp);
  else if (strcasecmp(arg1, "REGDELKEY") == 0)		puts(regdelkeyhelp);
  else if (strcasecmp(arg1, "REGLISTKEYS") == 0)	puts(reglistkeyshelp);
  else if (strcasecmp(arg1, "REGLISTVALS") == 0)	puts(reglistvalshelp);
  else if (strcasecmp(arg1, "REGDELVAL") == 0)		puts(regdelvalhelp);
  else if (strcasecmp(arg1, "REGSETVAL") == 0)		puts(regsetvalhelp);
  else if (strcasecmp(arg1, "HTTPON") == 0)		puts(httponhelp);
  else if (strcasecmp(arg1, "HTTPOFF") == 0)		puts(httpoffhelp);
  else if (strcasecmp(arg1, "TCPSEND") == 0)		puts(tcpsendhelp);
  else if (strcasecmp(arg1, "TCPRECV") == 0)		puts(tcprecvhelp);
  else if (strcasecmp(arg1, "LOCKUP") == 0)		puts(lockuphelp);
  else if (strcasecmp(arg1, "PLUGINEXEC") == 0)		puts(pluginexechelp);
  else if (strcasecmp(arg1, "PLUGINKILL") == 0)		puts(pluginkillhelp);
  else if (strcasecmp(arg1, "PLUGINLIST") == 0)		puts(pluginlisthelp);
  else
    printf("No help for '%s'\n", arg1);
}
